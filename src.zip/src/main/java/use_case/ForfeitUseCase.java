package use_case;

public class ForfeitUseCase {
}
